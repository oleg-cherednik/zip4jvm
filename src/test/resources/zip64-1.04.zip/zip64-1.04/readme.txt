zip64 - Readme
==============

This package includes a command-line tool for reading and
writing ZIP files which conform to the 64 bit extension
of the ZIP standard.

The only prerequisite to run the tool is the
availability of a JAVA instance (JAVA SE 1.5 or higher).

Copyright
The code for zip64 was created 2010 by Enter AG, Zurich,
and was placed in the public domain under the
GPL General Public License v2 or later. A copy of the license
is part of the distribution in the file gpl-2.0.txt. 

Install
Just unpack the distribution file to any directory to which the 
users of these programs have read and write access.

Release History
1.0  Published on SourceForge
1.01 Fixed error in EntryInputStream.skip()
1.02 Cleaned up the code, the build script and added "or later" to
     the GPL.
1.03 Fixed NullPointer exception on locked folder by issuing an IOException
     with a more understandable message.
1.04 Clean-up of utility classes to avoid clash of classes in SIARD Suite.

28.09.2011 Hartwig Thomas, Enter AG, Zurich, Switzerland
 